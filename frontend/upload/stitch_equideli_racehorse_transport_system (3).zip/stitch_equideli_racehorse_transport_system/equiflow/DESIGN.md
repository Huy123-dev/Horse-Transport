---
name: EQUIFLOW
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#43474e'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#465f86'
  primary: '#032448'
  on-primary: '#ffffff'
  primary-container: '#1f3a5f'
  on-primary-container: '#8ba4cf'
  inverse-primary: '#aec8f4'
  secondary: '#7e5708'
  on-secondary: '#ffffff'
  secondary-container: '#ffc974'
  on-secondary-container: '#795203'
  tertiary: '#342000'
  on-tertiary: '#ffffff'
  tertiary-container: '#503400'
  on-tertiary-container: '#c69d60'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#aec8f4'
  on-primary-fixed: '#001c3b'
  on-primary-fixed-variant: '#2d476d'
  secondary-fixed: '#ffddaf'
  secondary-fixed-dim: '#f3be6a'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#614000'
  tertiary-fixed: '#ffddb0'
  tertiary-fixed-dim: '#ecbf7f'
  on-tertiary-fixed: '#281800'
  on-tertiary-fixed-variant: '#5f410c'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-page:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-section:
    fontFamily: Be Vietnam Pro
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-card:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-default:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-medium:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  body-semibold:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  caption:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  badge-label:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  code-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 1.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
---

## Brand & Style

Hệ thống được định vị là nền tảng SaaS chuyên trách quản lý vận tải ngựa đua thể thao xuyên biên giới phục vụ kiểm soát tuân thủ, lịch thi đấu và thủ tục hải quan thú y. Bản sắc thiết kế phản ánh sự tin cậy tuyệt đối, tính kỷ luật cao của logistics hàng không/đường bộ, cùng với tinh thần sang trọng tối giản của giới thể thao cưỡi ngựa đẳng cấp cao.

Phong cách chủ đạo là **Corporate / Modern kết hợp Minimalism**:
- Giao diện dạng dashboard chuyên nghiệp, sáng rõ, mật độ thông tin tối ưu cho máy tính để bàn và máy tính bảng giám sát.
- Loại bỏ hoàn toàn hình ảnh nền trừu tượng hoặc ảnh ngựa toàn trang gây nhiễu thị giác; thay vào đó sử dụng cấu trúc lưới chặt chẽ, các khối thẻ (cards) mạch lạc và hệ thống màu trạng thái chuẩn xác.
- Tinh thần "equestrian luxury" được biểu đạt tinh tế thông qua sự tương phản giữa nền trắng sạch, màu xanh navy uy tín và các điểm nhấn ánh đồng (metallic bronze) dành riêng cho các chỉ số quan trọng, thời hạn đếm ngược và trạng thái thi đấu.
- Toàn bộ giao diện sử dụng 100% Tiếng Việt có dấu, chuẩn mực về thuật ngữ logistics và thú y, ngoại trừ các tiêu chuẩn mã định danh toàn cầu bắt buộc giữ nguyên ngữ (FEI, RFID, IATA, LAR, CITES).

## Colors

Hệ màu xây dựng trên nền tảng độ tương phản tiêu chuẩn WCAG AA cho văn bản và chỉ báo nghiệp vụ:

- **Primary (#1F3A5F)**: Xanh navy sâu, đại diện cho tính chuẩn hóa quốc tế, thanh điều hướng, nút hành động chính (Primary Actions) và các đầu mục quan trọng.
- **Secondary / Accent (#B8893B)**: Vàng đồng cao cấp, sử dụng có kiểm soát và tiết chế. Chỉ áp dụng cho đồng hồ đếm ngược lịch bay/thi đấu, mốc tiến độ mạ vàng danh dự, và huy hiệu quan trọng cần sự chú ý nhẹ nhàng thay vì cảnh báo khẩn cấp.
- **Background (#F5F6F8)**: Xám lạnh ngả sáng, bảo vệ thị lực trong phiên làm việc kéo dài, tạo sự tách biệt tự nhiên với các khối thẻ trắng.
- **Surface / Card (#FFFFFF)**: Trắng tuyệt đối, viền chuẩn `#E5E7EB`.
- **Hệ màu ngữ cảnh (Status Badges - Nền nhạt / Chữ đậm cùng tông)**:
  - *Thành công / Hoàn thành (Xanh lá)*: Nền `#ECFDF5`, Chữ `#065F46` (Đúng kế hoạch, Đủ điều kiện).
  - *Cảnh báo (Cam)*: Nền `#FFF7ED`, Chữ `#9A3412` (Có nguy cơ trễ, Sắp hết hạn).
  - *Nguy cấp / Lỗi (Đỏ)*: Nền `#FEF2F2`, Chữ `#991B1B` (Không đáp ứng lịch thi đấu, Bị từ chối, Có sự cố, Thiếu giấy tờ).
  - *Chấp thuận (Xanh dương)*: Nền `#EFF6FF`, Chữ `#1E40AF` (Đã phê duyệt).
  - *Đang luân chuyển (Chàm)*: Nền `#EEF2FF`, Chữ `#3730A3` (Đang vận chuyển).
  - *Chăm sóc y tế (Tím)*: Nền `#FAF5FF`, Chữ `#6B21A8` (Đang hồi phục, Kiểm dịch y tế).
  - *Trung tính / Chờ (Xám)*: Nền `#F3F4F6`, Chữ `#374151` (Đang chờ, Đang kiểm tra).

## Typography

Hệ thống sử dụng phông chữ **Be Vietnam Pro** làm nền tảng toàn diện để đảm bảo hiển thị dấu thanh tiếng Việt cân đối, nét chữ hiện đại và không bị lỗi hiển thị trên mọi nền tảng.

- **Tiêu đề trang (24px, Semibold/Bold)**: Dùng cho tiêu đề cấp cao nhất của từng phân hệ (ví dụ: *Tổng quan vận chuyển*, *Hồ sơ kiểm dịch*).
- **Tiêu đề thẻ/khối (16px, Semibold)**: Xác định từng nhóm chức năng độc lập trong dashboard.
- **Nội dung chung (14px, Regular/Medium)**: Đạt độ đọc tối ưu trên các bảng dữ liệu (Data Table), mô tả lộ trình và biểu mẫu.
- **Chú thích & Nhãn trạng thái (12px, Regular/Semibold)**: Dùng cho timestamp, đơn vị tính, văn bản hỗ trợ và huy hiệu trạng thái (Badges).
- **Mã kỹ thuật (13px, Monospaced)**: Dành riêng cho việc hiển thị các mã định danh kỹ thuật như FEI ID, mã vi mạch RFID, chuyến bay IATA hoặc tiêu chuẩn LAR nhằm bảo đảm các chữ số và ký tự căn chỉnh thẳng hàng dọc.

## Layout & Spacing

Hệ thống vận hành theo quy tắc bội số **8px** (8-point grid system), tạo nhịp điệu hiển thị chặt chẽ và nhất quán:

- **Bố cục chính**: Khung dashboard gồm Sidebar điều hướng cố định (rộng 260px) và Content Canvas dạng Fluid Grid mở rộng tự nhiên theo độ phân giải màn hình máy tính (tối thiểu 1280px).
- **Thẻ nội dung (Cards)**: Đặt padding đồng nhất **20px** (`1.25rem` / `space-lg`) ở mọi cạnh, khoảng cách giữa các thẻ kế nhau trên lưới (Gutter) là 24px (`1.5rem`).
- **Khoảng cách phần tử (Inner Spacing)**:
  - Khoảng cách giữa tiêu đề thẻ và nội dung: 16px (`space-md`).
  - Khoảng cách giữa các nhãn và ô nhập liệu: 8px (`space-sm`).
  - Khoảng cách giữa icon và nhãn văn bản: 8px (`space-sm`).
  - Khoảng cách phân đoạn thông tin phụ: 4px (`space-xs`).

## Elevation & Depth

Thiết kế loại bỏ các hiệu ứng bóng đổ nặng nề, tập trung vào chiều sâu tinh giản (Subtle Depth) thông qua viền mảnh và bóng mờ đa tầng cực nhẹ:

- **Mặt phẳng cơ sở (Canvas Base)**: Nền xám `#F5F6F8` phẳng hoàn toàn, không bóng.
- **Mặt thẻ (Card Surface)**: Nền trắng `#FFFFFF`, viền đơn sắc nét `#E5E7EB` (độ dày 1px), kết hợp bóng đổ vi tế: `0 1px 3px 0 rgba(0, 0, 0, 0.04), 0 1px 2px 0 rgba(0, 0, 0, 0.02)`.
- **Mặt nổi tương tác (Hover / Active Cards)**: Khi di chuột hoặc kích hoạt, viền chuyển sắc nhẹ sang `#D1D5DB`, bóng nâng nhẹ: `0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)`.
- **Menu thả xuống & Hộp thoại (Dropdowns / Modals)**: Nền `#FFFFFF`, viền `#E5E7EB`, bóng mở rộng: `0 10px 15px -3px rgba(0, 0, 0, 0.08), 0 4px 6px -2px rgba(0, 0, 0, 0.04)`.

## Shapes

Ngôn ngữ hình khối được phân cấp rõ ràng theo kích thước và mục đích của thành phần:

- **Thẻ nội dung & Khung dữ liệu (Cards & Containers)**: Bo góc chuẩn **12px** (`rounded-xl` tương đương 0.75rem trong ngữ cảnh thẻ dashboard), tạo cảm giác mềm mại, thanh lịch nhưng vẫn giữ được tính cấu trúc.
- **Thành phần tương tác (Buttons, Inputs, Selects)**: Bo góc chuẩn **8px** (`rounded-md` / 0.5rem), tối ưu cho nút thao tác chiều cao 40px.
- **Huy hiệu trạng thái (Badges / Chips)**: Bo tròn hoàn toàn (Pill-shaped, `rounded-full` 9999px) để tạo sự tương phản rõ nét với cấu trúc hình hộp của các thẻ dữ liệu.
- **Hộp kiểm (Checkboxes)**: Bo góc nhỏ **4px** (`rounded-sm`).
- **Nút chọn duy nhất (Radio Buttons)**: Bo tròn 100% hình cầu.

## Components

### 1. Nút bấm (Buttons)
- **Kích thước tiêu chuẩn**: Chiều cao cố định **40px**, padding ngang 16px, bo góc 8px, chữ 14px Semibold.
- **Nút chính (Primary Button)**: Nền xanh navy `#1F3A5F`, chữ trắng `#FFFFFF`. Khi di chuột (hover) chuyển sang `#162A45`. Khi nhấn (active) chuyển sang `#101F33`.
- **Nút phụ (Secondary / Outline Button)**: Nền trong suốt hoặc `#FFFFFF`, viền xám `#D1D5DB`, chữ `#1F3A5F`. Khi di chuột: nền `#F9FAFB`, viền `#9CA3AF`.
- **Nút đặc biệt (Accent / Highlight)**: Dùng nền vàng đồng `#B8893B`, chữ trắng `#FFFFFF`, chỉ dùng cho hành động thúc đẩy tiến độ hoặc gia hạn quan trọng.

### 2. Huy hiệu trạng thái (Status Badges)
Thiết kế bo tròn hoàn toàn (Pill), padding dọc 4px, ngang 12px, cỡ chữ 12px Semibold, nền nhạt phối chữ đậm cùng tông:
- **Đúng kế hoạch / Đủ**: Nền `#ECFDF5`, Chữ `#065F46` (Xanh lá).
- **Có nguy cơ trễ / Sắp hết hạn**: Nền `#FFF7ED`, Chữ `#9A3412` (Cam).
- **Không đáp ứng lịch thi đấu / Bị từ chối / Có sự cố / Thiếu giấy tờ**: Nền `#FEF2F2`, Chữ `#991B1B` (Đỏ).
- **Đã phê duyệt**: Nền `#EFF6FF`, Chữ `#1E40AF` (Xanh dương).
- **Đang vận chuyển**: Nền `#EEF2FF`, Chữ `#3730A3` (Chàm).
- **Đang hồi phục / Kiểm dịch**: Nền `#FAF5FF`, Chữ `#6B21A8` (Tím).
- **Đang chờ / Đang kiểm tra**: Nền `#F3F4F6`, Chữ `#374151` (Xám).

### 3. Thẻ dữ liệu (Cards)
- Nền `#FFFFFF`, viền `#E5E7EB`, bán kính bo góc 12px, padding đồng nhất 20px.
- Phần đầu thẻ (Card Header) chứa tiêu đề 16px Semibold, kèm theo vị trí đặt huy hiệu hoặc nút thao tác nhanh ở góc phải.

### 4. Ô nhập liệu (Input Fields & Selects)
- Chiều cao 40px, viền `#D1D5DB`, bo góc 8px, nền `#FFFFFF`, padding ngang 12px, chữ 14px Regular.
- Khi trỏ chuột lấy nét (Focus): Viền chuyển `#1F3A5F`, phủ vòng sáng nhẹ `box-shadow: 0 0 0 2px rgba(31, 58, 95, 0.15)`.

### 5. Thành phần đặc thù bổ sung
- **Bộ đếm ngược thời gian bay/thi đấu (Countdown Metric Widget)**: Khối thẻ viền điểm xuyết màu đồng `#B8893B` dày 2px ở mép trái, số giờ đếm ngược hiển thị 24px Bold màu `#B8893B`, chú thích 12px xám.
- **Thẻ mã định danh ngựa (Equine ID Snippet)**: Khối hiển thị thông tin vi mạch gắn kèm biểu tượng chip, mã FEI/RFID hiển thị phông đơn cách (JetBrains Mono) với tính năng bấm để sao chép nhanh một chạm.
- **Thanh tiến trình chặng vận chuyển (Multi-leg Route Stepper)**: Các trạm dừng hải quan kết nối bằng đường nối 2px màu `#E5E7EB`, trạm hoàn thành đổi màu Navy `#1F3A5F`, trạm có cảnh báo chuyển Cam `#9A3412`.